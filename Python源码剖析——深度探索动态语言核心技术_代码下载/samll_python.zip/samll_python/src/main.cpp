#include <iostream>
using namespace std;

#include "object.h"
#include "intObject.h"
#include "engine.h"

int main()
{
	ExcuteEngine engine;
	engine.Excute();
	return 0;
}

